package Jan11;

class Area
{
	void area1(double a)
	{
		double area = 3.14*a*a;
		System.out.println("The area of circle : "+area);
	}
	void area1(double a,double b)
	{
		double area = (a*b)/2;
		System.out.println("The area of triangle : "+area);	
	}
	void rectangle(double l,double h)
	{
		double area = l*h;
		System.out.println("The area of rectangle : "+area);	
	}
	

}

public class areaexercise {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Area t=new Area();
		t.area1(33.63);
		t.area1(2,5);
		t.rectangle(4,5);
	}

}
