package Jan11;
class Employee1
{
	int id;
	String name;
	int salary;
	
	public Employee1()
	{
		id=101;
		name="JEeva";
		salary=30000;
	}
	
	public void display()
	{
		System.out.println("The Employee id"+id);
		System.out.println("The Employee Name"+name);
		System.out.println("The Employee Salary"+salary);
	}

}

public class ConstructorTesting {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Employee1 e=new Employee1();
		e.display();

	}

}
