package Jan11;
class Type
{
	int sum(int a)
	{	
		return a+10;
	}
}
public class typeconversion {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Type c=new Type();
		System.out.println(c.sum(20));
	}

}
