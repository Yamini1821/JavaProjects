package Jan11;

class Methods
{
	int add(int a)
	{
		return a+10;
	}
	void add(int a, int b, int c)
	{
		System.out.println(a+b+c);
	}
	double add(int a, int b)
	{
		return a+b;
		
	}
}


public class MethodOVerloadingTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Methods s=new Methods();
		s.add(10,20,30);
		System.out.println(s.add(20));
		System.out.println(s.add(20,30));

	}

}
