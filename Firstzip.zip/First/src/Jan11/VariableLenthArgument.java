package Jan11;

class M
{
	int total(int... a)
	{
		int sum=0;
		for(int s:a)
		{
			sum=sum+s;
		}
		return sum;
	}
}

public class VariableLenthArgument {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		M m=new M();
		System.out.println(m.total(10,20,30,40,50));

	}

}
