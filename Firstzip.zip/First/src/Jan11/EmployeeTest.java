package Jan11;
import java.util.*;
class Employee
{
	 int id;
	String name;
	int salary;
	public void setter()
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the Employee id");
		id=sc.nextInt();
		System.out.println("Enter the Employee name");
		name=sc.next();
		System.out.println("enter the Employee Salary");
		salary=sc.nextInt();
	}
	public void display()
	{
		System.out.println("The Employee id"+id);
		System.out.println("The Employee Name"+name);
		System.out.println("The Employee Salary"+salary);
	}
	
	
}

public class EmployeeTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Employee e=new Employee();
		e.setter();
		e.id=102;
		e.display();
		Employee e2=new Employee();
		e2.setter();
		e2.display();

	}

}
