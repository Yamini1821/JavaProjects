package Jan11;
class Methodss
{
	public Methodss(int a)
	{
		this(10,20);
		System.out.println( a+10);
	}
	public Methodss(int a, int b, int c)
	{
		System.out.println(a+b+c);
	}
	public Methodss(int a, int b)
	{
		this(2,3,4);
		System.out.println( a+b);
		
	}
	public Methodss()
	{
		this(10);
		System.out.println("Jeeva");
	}
}
public class ConstructorOverloadingTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Methodss o=new Methodss();

	}

}
