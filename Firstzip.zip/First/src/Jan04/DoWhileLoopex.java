package Jan04;

public class DoWhileLoopex {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=101;
		do
		{
			System.out.println(a);
			a=a+1;
		}while(a<=100);

	}

}
