package Jan04;

import java.util.Scanner;

public class IfElseex2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter the a value");
		int age=sc.nextInt();
		if(age>=18)
		{
			System.out.println("Is eligible to vote");
		}
		else
		{
			System.out.println("ITs not eligible to vote");
		}

	}

}
