package Jan04;
import java.util.*;

public class Ifelseex1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter the a value");
		int a=sc.nextInt();
		System.out.println("Enter the b value");
		int b=sc.nextInt();
		
		if(a>b)
		{
			System.out.println("A is big");
		}
		else
		{
			System.out.println("B is big");
		}

	}

}
