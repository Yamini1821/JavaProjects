package Jan04;

import java.util.Scanner;

public class evenorodd {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter the a value");
		int a=sc.nextInt();
		if(a%2==0)
		{
			System.out.println(a+"is even");
		}
		else {
			System.out.println(a+"is odd");
		}
	}

}
