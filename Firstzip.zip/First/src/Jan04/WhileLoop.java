package Jan04;

public class WhileLoop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int a=1;
		while(a<=100)
		{
			System.out.println(a);
			a=a+1;
		}

	}

}
