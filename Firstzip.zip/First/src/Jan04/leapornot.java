package Jan04;

import java.util.Scanner;

public class leapornot {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
   Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter the year");
		int a=sc.nextInt();
		if(a%4==0)
		{
			System.out.println(a+"is leap year");
		}
		else {
			System.out.println(a+"is not a leap year");
		}
	}

}
