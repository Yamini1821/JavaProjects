package Jan04;

import java.util.Scanner;

public class SwitchExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter the a value");
		int a=sc.nextInt();
		System.out.println("Enter the b value");
		int b=sc.nextInt();
		
		int c;
		
		System.out.println("Enter the Choice");
		int ch=sc.nextInt();
		
		
		switch(ch)
		{
		case 1:
			c=a+b;
			System.out.println(c);
			break;
		case 2:
			c=a-b;
			System.out.println(c);
			break;
		case 3:
			c=a*b;
			System.out.println(c);
			break;
		default:
			System.out.println("Invalid choices");
		}
		

	}

}
