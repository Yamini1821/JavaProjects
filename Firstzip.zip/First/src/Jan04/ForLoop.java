package Jan04;

public class ForLoop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		for(int i=100;i>=1;i--)
		{
			System.out.println(i);
		}

	}

}
